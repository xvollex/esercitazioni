USE esercizio_db;

CREATE TABLE ruolo (
    ID_R INT AUTO_INCREMENT PRIMARY KEY,
    tipologia ENUM('Admin', 'Utente', 'Docente')
);

CREATE TABLE utente (
    ID_U INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255),
    cognome VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255)
);

CREATE TABLE utente_ruolo (
    FK_U INT NOT NULL,
    FK_R INT NOT NULL,
    FOREIGN KEY (FK_U) REFERENCES utente (ID_U),
    FOREIGN KEY (FK_R) REFERENCES ruolo (ID_R)
);

CREATE TABLE categoria (
	ID_CA INT AUTO_INCREMENT PRIMARY KEY,
    Nome_Categoria ENUM('FrontEnd', 'BackEnd', 'FullStack', 'Cybersecurity')
);

CREATE TABLE corso (
    ID_C INT AUTO_INCREMENT PRIMARY KEY,
    Nome_Corso VARCHAR(255),
    Descrizione_breve VARCHAR(255),
    Descrizione_completa TEXT,
    durata INT,
    FK_CA INT,
    FOREIGN KEY (FK_CA) REFERENCES categoria (ID_CA)
);

CREATE TABLE utenti_corsi (
    FK_UC INT NOT NULL,
    FK_CU INT NOT NULL,
    FOREIGN KEY (FK_UC) REFERENCES utente (ID_U),
    FOREIGN KEY (FK_CU) REFERENCES corso (ID_C)
);

